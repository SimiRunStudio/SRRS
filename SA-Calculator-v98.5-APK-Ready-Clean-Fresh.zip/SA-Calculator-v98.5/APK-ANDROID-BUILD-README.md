# Android APK build

This source release is prepared to generate a Capacitor Android project and build a debug APK in GitHub Actions. It does **not** contain a prebuilt APK or a generated `android/` Gradle project.

## GitHub Actions (recommended)
1. Upload/push the complete project to GitHub.
2. Open **Actions → Android APK**.
3. Select **Run workflow** and start it on the branch you want to build.
4. When the workflow succeeds, open its run and download the `sa-calculator-debug-apk` artifact. The APK is `app-debug.apk`.

The workflow installs the pinned-major Capacitor 7 packages, runs the full Node regression suite, copies the offline web assets into `www/`, generates the Android project, syncs it, and builds the debug APK.

## Local build requirements
- Node.js 22+
- Java 21
- Android SDK and Android build tools (configured through Android Studio)

Commands:

```sh
npm install
npm test
npm run android:project
npm run android:apk
```

`android:project` creates the native `android/` project once. After it exists, use `npm run android:sync` after web-source changes, then `npm run android:apk`.

A debug APK is for testing. A release APK/AAB requires a user-owned signing key and secure signing configuration; no signing credentials are included in this ZIP.
