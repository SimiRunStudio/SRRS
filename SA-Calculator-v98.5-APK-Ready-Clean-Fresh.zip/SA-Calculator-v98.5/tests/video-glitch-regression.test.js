'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');

test('saved accent is resolved before the main stylesheet to prevent first-paint palette flash', () => {
  const html = read('index.html');
  assert.ok(html.indexOf('assets/js/theme-bootstrap.js') < html.indexOf('assets/css/app.css'));
  const bootstrap = read('assets/js/theme-bootstrap.js');
  assert.match(bootstrap, /sumaire_settings_master/);
  assert.match(bootstrap, /--sa-initial-accent/);
  const css = read('assets/css/app.css');
  assert.match(css, /--primary-blue:\s*var\(--sa-initial-accent, #1765f5\)/);
  assert.match(css, /--accent-cyan:\s*var\(--sa-initial-accent, #1765f5\)/);
});

test('toast is anchored in the display area and no longer covers the bottom keypad row', () => {
  const css = read('assets/css/app.css');
  const start = css.indexOf('#app-toast {');
  const end = css.indexOf('\n}', start);
  const rule = css.slice(start, end);
  assert.match(rule, /top:\s*calc\(60px \+ env\(safe-area-inset-top, 0px\)\)/);
  assert.match(rule, /bottom:\s*auto/);
});

test('manual currency refresh ignores rapid repeat taps while automatic refresh stays silent', () => {
  const app = read('assets/js/app.js');
  assert.match(app, /let currencyManualRefreshCooldownUntil = 0/);
  assert.match(app, /now < currencyManualRefreshCooldownUntil/);
  assert.match(app, /currencyManualRefreshCooldownUntil = now \+ 5000/);
  assert.match(app, /setActiveInput\(amountEl\); calcCurrency\(\); refreshCurrencyRates\(false\); scheduleCurrencyAutoRefresh\(\)/);
});

test('live-preview Error preserves the exact 32px preview lane geometry', () => {
  const css = read('assets/css/app.css');
  const marker = 'SA Calculator v1.97.9-v97.9 — error state must preserve preview row geometry.';
  const start = css.lastIndexOf(marker);
  assert.ok(start >= 0, 'final recording-driven error-row stability layer exists');
  const layer = css.slice(start);
  assert.match(layer, /#screen-calc \.calc-preview-row,[\s\S]*?flex:0 0 32px !important/);
  assert.match(layer, /min-height:32px !important/);
  assert.match(layer, /height:32px !important/);
  assert.match(layer, /max-height:32px !important/);
  assert.match(layer, /align-items:center !important/);
  assert.doesNotMatch(layer, /min-height:clamp\(48px,9vh,76px\)/);
  assert.match(layer, /font-size:var\(--calc-preview-fitted-size,28px\) !important/);
  assert.match(layer, /color:#c62828 !important/);
});

test('preview Error changes semantic color without changing row sizing or baseline metrics', () => {
  const css = read('assets/css/app.css');
  const marker = 'SA Calculator v1.97.9-v97.9 — error state must preserve preview row geometry.';
  const layer = css.slice(css.lastIndexOf(marker));
  const rowStart = layer.indexOf('#screen-calc .calc-preview-row,');
  const rowEnd = layer.indexOf('}', rowStart);
  const rowRule = layer.slice(rowStart, rowEnd);
  assert.match(rowRule, /flex:0 0 32px !important/);
  assert.match(rowRule, /height:32px !important/);
  const committedStart = layer.indexOf('#screen-calc .calc-display.result-mode.result-error-mode #calc-preview-row');
  const committedEnd = layer.indexOf('}', committedStart);
  const committedRule = layer.slice(committedStart, committedEnd);
  assert.match(committedRule, /display:none !important/);
  assert.match(committedRule, /height:0 !important/);
  const errorTextStart = layer.indexOf('#screen-calc #calc-display-box.preview-error-mode #calc-preview-row #calc-val {');
  const errorTextEnd = layer.indexOf('}', errorTextStart);
  const valueRule = layer.slice(errorTextStart, errorTextEnd);
  assert.match(valueRule, /line-height:normal !important/);
  assert.match(valueRule, /letter-spacing:0\.3px !important/);
  assert.doesNotMatch(valueRule, /line-height:1\.12/);
  assert.doesNotMatch(valueRule, /letter-spacing:-1\.5px/);
});

test('live Error retains the same 25px horizontal boundary inset', () => {
  const css = read('assets/css/app.css');
  const marker = 'SA Calculator v1.97.9-v97.9 — error state must preserve preview row geometry.';
  const layer = css.slice(css.lastIndexOf(marker));
  const rowStart = layer.indexOf('#screen-calc #calc-display-box.preview-error-mode #calc-preview-row {');
  const rowEnd = layer.indexOf('}', rowStart);
  const rowRule = layer.slice(rowStart, rowEnd);
  assert.match(rowRule, /margin-left:var\(--calc-horizontal-gutter,25px\) !important/);
  assert.match(rowRule, /margin-right:var\(--calc-horizontal-gutter,25px\) !important/);
});

test('preview fitting publishes one measured font size for normal values and Error', () => {
  const app = read('assets/js/app.js');
  const css = read('assets/css/app.css');
  assert.match(app, /--calc-preview-fitted-size.*\$\{rawSize\}px/);
  assert.match(app, /--calc-preview-fitted-size.*\$\{minSize\}px/);
  assert.match(css, /font-size:var\(--calc-preview-fitted-size,28px\) !important/);
});


test('live and committed Error rows keep the same 25px horizontal boundary inset', () => {
  const css = read('assets/css/app.css');
  const marker = 'SA Calculator v1.97.9-v97.9 — error state must preserve preview row geometry.';
  const layer = css.slice(css.lastIndexOf(marker));
  const rowStart = layer.indexOf('#screen-calc #calc-display-box.preview-error-mode #calc-preview-row {');
  const rowEnd = layer.indexOf('}', rowStart);
  const rowRule = layer.slice(rowStart, rowEnd);
  assert.match(rowRule, /margin-left:var\(--calc-horizontal-gutter,25px\) !important/);
  assert.match(rowRule, /margin-right:var\(--calc-horizontal-gutter,25px\) !important/);
});
