import { cp, mkdir, rm, access } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const out = path.join(root, 'www');
const required = ['index.html', 'assets/css/app.css', 'assets/js/app.js', 'assets/js/localization.js', 'assets/js/currency-localized-names.js', 'assets/js/theme-bootstrap.js', 'assets/brand/sa-calculator-icon.png'];
for (const item of required) {
  try { await access(path.join(root, item)); }
  catch { throw new Error(`Required app asset is missing: ${item}`); }
}
await rm(out, { recursive: true, force: true });
await mkdir(out, { recursive: true });
for (const item of ['index.html', 'manifest.webmanifest', 'assets']) {
  await cp(path.join(root, item), path.join(out, item), { recursive: true });
}
console.log(`Android web bundle prepared: ${required.length} required assets verified.`);
