# SA Calculator v92 — Video Glitch Audit

## Observed in `Screenrecording_20261113_212654.mp4`

1. **Accent-color flash:** the first rendered frame can use the legacy teal CSS fallback, then switch to the saved/default blue accent after `DOMContentLoaded` restores settings. The recording shows blue/teal color changes across the calculator controls.
2. **Toast overlaps keypad:** the exchange-rate success toast is positioned at the bottom of the app viewport and covers the bottom number row / equals key area on a phone-sized screen.
3. **Repeated manual refresh feedback:** repeated taps on the header refresh control can trigger a sequence of success toasts and make the screen feel flickery, even when the user is not working in the currency screen.

## Fixes in v1.92.4-v92

- Added `assets/js/theme-bootstrap.js`, loaded before the stylesheet, to validate and restore the saved accent before first paint. The fallback is the same blue accent as a fresh install.
- Updated theme CSS fallbacks to use the early accent token, avoiding a teal-to-blue palette flash.
- Moved the app toast to the display region immediately below the header. It no longer overlays the bottom keypad controls.
- Added a five-second repeat-tap guard to the manual currency refresh control. Background/automatic refresh remains silent.
- Updated service-worker cache key and precache list to ensure installed PWA copies fetch the new bootstrap and CSS/JS.

## Verification

- `npm test`: 63 passed, 0 failed.
- JavaScript syntax checks: `assets/js/theme-bootstrap.js`, `assets/js/app.js`, `server.js`, `service-worker.js` passed.
- Local HTTP smoke checks: index, bootstrap script and stylesheet each returned HTTP 200.
- ZIP integrity verified after packaging.

## Remaining device verification

The video-based fixes are covered by regression tests and static/local HTTP checks. Final touch feel, viewport-specific toast placement and cold-start rendering should still be confirmed on the user's Android device after replacing the old PWA/browser cache.


## Release polish follow-up

- Toast feedback is now exposed as a polite atomic status region for screen readers.
- Historical v1.92.4-v92 suite: 65 passed, 0 failed, 0 skipped.
- Release metadata and service-worker cache identity were advanced to `1.92.4-v92` so installed copies can update cleanly.


## v1.92.4-v92 currency-converter recording fixes (2026-11-13)
- Removed the refresh button from the global app header and placed it in a dedicated Currency Converter-only toolbar.
- Corrected the refresh toast count to use the selectable 105-currency catalogue and only count currencies with valid positive rates. Provider-only ISO/API extras no longer inflate the UI count.
- Fixed `[object Object]` provider metadata by using concise `Frankfurter v2` attribution and sanitizing legacy cached labels from prior app versions.
- Limited the primary rate note to two lines and constrained status wrapping so metadata cannot expand over the keypad.
- Added regression gates for refresh placement, count source, metadata sanitization and provider labels.
- Current automated suite: 75 passed, 0 failed, 0 skipped. Android device visual verification remains pending.

## v1.92.7-v92 currency interaction and status refinement

- Dedicated pair swap now exchanges the source and destination amount values along with the currency codes.
- Destination amount is an accessible editable decimal field; the existing reverse calculation path is now accurately reflected in its semantics.
- Rate provider/offline status and last-checked/last-successful-update timestamps are visible again; the previous stylesheet override had hidden them.
- Regression suite: 75 passed, 0 failed, 0 skipped. Physical Android/WebView verification remains pending.

## v1.92.7-v92 startup micro-audit

- Removed duplicate currency-cache parsing during startup. Cache restoration now occurs once, inside `initCurrencies()`, before pair setup and initial conversion.
- Clarified the fixed 105-currency picker contract in the source comment; provider-only quote keys remain excluded from visible rows and refresh counts.
- Added a regression test to prevent duplicate startup cache restoration.
