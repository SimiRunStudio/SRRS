const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, '..');
const read = p => fs.readFileSync(path.join(root, p), 'utf8');

test('Capacitor Android wrapper is configured for a local offline web bundle', () => {
  const config = JSON.parse(read('capacitor.config.json'));
  assert.equal(config.appId, 'com.sacalculator.app');
  assert.equal(config.appName, 'SA Calculator');
  assert.equal(config.webDir, 'www');
  assert.equal(config.server.androidScheme, 'https');
  assert.equal(config.android.allowMixedContent, false);
});

test('Android build workflow runs regression tests and publishes the debug APK', () => {
  const workflow = read('.github/workflows/android-apk.yml');
  for (const expected of ['npm test', 'npm run build:web', 'npx cap add android', 'npx cap sync android', './gradlew --no-daemon assembleDebug', 'actions/upload-artifact@v4', 'app-debug.apk']) {
    assert.ok(workflow.includes(expected), `Missing Android build step: ${expected}`);
  }
});

test('Android web bundle builder verifies all runtime assets before copying', () => {
  const script = read('scripts/prepare-android-web.mjs');
  for (const asset of ['index.html', 'assets/css/app.css', 'assets/js/app.js', 'assets/js/localization.js', 'assets/js/currency-localized-names.js', 'assets/js/theme-bootstrap.js', 'assets/brand/sa-calculator-icon.png']) {
    assert.ok(script.includes(asset), `Missing required web asset: ${asset}`);
  }
});
