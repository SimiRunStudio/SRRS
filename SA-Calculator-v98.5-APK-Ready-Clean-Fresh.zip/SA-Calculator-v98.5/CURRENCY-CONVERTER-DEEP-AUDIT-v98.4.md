# Currency Converter Deep Audit — v98.4

Date: 2026-11-14
Base: v98.3 Settings & Tools Clean release

## Scope reviewed
- Currency catalogue and localized names; picker search, alphabetical sections, A–Z navigation and selected-state behavior.
- Saved from/to pair persistence and pair swapping, including preservation of the exact raw displayed amounts.
- Both editable amount fields, keypad focus/navigation, reverse conversion and derived-value metadata.
- Decimal multiplication/division, bounded precision, ISO currency minor-unit rounding and large-amount formatting.
- Frankfurter v2, Open ER-API and Fawaz Exchange API provider normalization, fallback ordering, timeout handling, per-currency observation dates and source attribution.
- Rate cache validation, offline estimate labeling, last-known-rate behavior, refresh timestamps, retry/backoff, online/visibility refresh and service-worker API cache exclusion.
- Accessibility/status labels and responsive result fitting.

## Findings from source and automated verification
- Existing implementation has dedicated automated coverage for rate freshness, provider precedence, per-currency merge safety, cache validation, decimal math, ISO minor units, pair persistence, swap, both editable fields, picker behavior, refresh throttling and timestamp integrity.
- The selected-pair conversion uses USD-base rate ratios and decimal-string/BigInt arithmetic rather than binary floating-point multiplication for the conversion result.
- A pair's observation date is based on its constituent currency observations; the converter distinguishes last checked time from last successful rate update.
- Built-in rates are explicitly estimates; cached and online observations are labelled separately. Provider rates are reference rates, not guaranteed bank/card/remittance execution quotes.
- Rate API responses are not cached by the service worker. Cached observations are separately validated before reuse.
- No currency logic regression was required by this audit; the existing implementation was retained rather than introducing risky changes to rate math or provider selection without a reproduced defect.

## Automated checks
- Full project test suite: 146 passed, 0 failed, 0 skipped on the v98.3 source before release metadata bump.
- Currency-focused tests include provider refresh order and newer-date precedence, per-currency cache validation, cross-currency ratios, decimal precision, minor-unit rounding, selected pair persistence, reverse editing, swap preservation, picker catalogue and refresh metadata.
- This v98.4 release changes version/cache identity and adds this audit report; calculator and currency runtime logic are unchanged from the tested v98.3 source.

## Known verification limits
- The four screen recordings uploaded on 2026-11-14 show calculator/scientific-entry flows, not the Currency Converter screen; they cannot establish currency UI behavior.
- Automated Node tests and static checks do not replace physical Android WebView testing, touch testing, or live-network testing on the user's device.
- Exchange-rate providers may be unavailable, rate-limited, delayed, or publish on different schedules. A refresh cannot force an upstream provider to publish a newer observation.
