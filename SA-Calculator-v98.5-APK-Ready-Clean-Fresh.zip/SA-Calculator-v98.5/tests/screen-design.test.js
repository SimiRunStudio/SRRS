const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, '..');
const css = fs.readFileSync(path.join(root, 'assets/css/app.css'), 'utf8');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const sw = fs.readFileSync(path.join(root, 'service-worker.js'), 'utf8');

test('screen design layer includes consistent touch targets, responsive layouts and safe areas', () => {
  assert.ok(css.includes('v1.97.1-v97.1 — retained screen-design layer; runtime changes are in app.js/server.js'));
  assert.match(css, /\.main-keypad \.key-btn \{ min-height:48px/);
  assert.match(css, /\.app-header \.icon-btn \{ width:48px; min-width:48px; height:48px; min-height:48px;/);
  assert.match(css, /\.settings-row \{ min-height:60px/);
  assert.match(css, /\.currency-picker-row \{ min-height:48px/);
  assert.match(css, /env\(safe-area-inset-bottom\)/);
  assert.match(css, /@media \(max-width:380px\)/);
  assert.match(css, /@media \(max-height:620px\)/);
  assert.match(css, /@media \(min-width:600px\)/);
  assert.match(css, /prefers-reduced-motion:reduce/);
  assert.match(css, /forced-colors:active/);
});

test('screen design update preserves all 18 registered app destinations and release cache version', () => {
  const screens = [...html.matchAll(/id="screen-[a-z0-9-]+"/g)].map(m => m[0]);
  assert.equal(new Set(screens).size, 19); // viewport plus 18 destinations
  assert.match(html, /1\.98\.5-v98\.5/);
  assert.match(sw, /sa-calculator-v98-5-android-ready-cleanup/);
});
