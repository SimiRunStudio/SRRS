# SA Calculator v92 — Current file-by-file audit

Release: `1.97.1-v97.1`  
Audit date: 2026-11-14  
Input: `SA-Calculator-v92-RELIABILITY-HARDENED-v1.95.0.zip` plus the user-supplied 14-Nov-2026 screen recording

## Runtime files

| File | Responsibility | Current audit result |
|---|---|---|
| `index.html` | App shell, 17 tool screens, picker, settings and dialogs | Unique IDs and local asset references covered by release tests; toast now has accessible status semantics. |
| `assets/js/app.js` | Calculator engines, navigation, currency providers, settings, history and persistence | Syntax and regression tests pass; public provider fallback and offline cache retained. |
| `assets/js/theme-bootstrap.js` | First-paint accent restoration | Loaded before stylesheet; included in service-worker precache. |
| `assets/css/app.css` | Themes, calculator layouts, dialogs and responsive rules | CSS parser check passes; final design layer adds consistent touch targets, adaptive widths/heights, safe areas, focus states and reduced-motion support. Physical viewport rendering still requires Android testing. |
| `service-worker.js` | Offline app shell | Current cache key is `sa-calculator-v97-1-97-1-symlink-hardening`; same-origin API routes are not cached. |
| `server.js` | Optional local static development server | Syntax and HTTP smoke/security tests pass; not a currency proxy or production API server. |
| `manifest.webmanifest` | PWA metadata and launcher icon | JSON valid; version aligned to `1.97.1-v97.1`. |
| `package.json` | Project metadata and test command | Valid JSON; no third-party runtime dependencies required for app operation. |
| `assets/brand/sa-calculator-icon.png` | PWA/launcher icon | Retained; no generated or competitor brand assets added. |

## Test files

The `tests/` directory covers currency freshness/math/pair persistence/provider fallback, calculator parsing and scientific notation, tool calculations, history/settings, navigation, HTML/runtime integration, server safety, video-glitch regressions and release metadata. Run with `npm test`; current result: **115 passed, 0 failed, 0 skipped**.

## Currency architecture

- Frankfurter v2 is the primary public reference-rate source.
- Open ER-API and Fawaz Exchange API are fallbacks; the Fawaz jsDelivr and Cloudflare Pages URLs mirror the same dataset and are not independent market sources.
- No private Cloudflare Worker, private API adapter, provider credential or server-side currency proxy is shipped in this package.
- Cached observations retain their provider date and provenance; built-in estimates remain labelled as estimates when no current provider response is available.

## Release consistency

The app version is `1.97.1-v97.1` across package, manifest, HTML, feedback metadata and release documentation. The service-worker cache namespace is advanced for this release. The release gate checks metadata consistency, asset references, unique IDs, syntax, CSS structure, app actions, settings/history safeguards, provider behavior and server routes.

## Limits

Automated checks do not prove physical Android/WebView rendering, universal zero-lag performance, live provider uptime, legal clearance, or signed APK readiness. Those require device, network and distribution-specific verification.


| `assets/js/localization.js` | Offline-first UI localization | 8 language modes; 628 shared translation keys; 400-entry static UI inventory; 76 unit labels; dynamic templates, plural rules, placeholders, locale formatting and RTL support. Currency display names have a bundled 105-currency CLDR fallback for all eight locales. Native-speaker and device-level validation remain outstanding. |


The v1.97.1-v97.1 scientific-result continuation changes are documented in `RELEASE-VERIFICATION.md`; the earlier v1.95.0 server and picker changes remain covered by HTTP integration regression tests.
